// const express = require('express');
// const fs = require('fs');
// const app = express();

// app.use(express.json());

// const filePath = './users.json';

// function readUsers() {
//     try {
//         return JSON.parse(fs.readFileSync(filePath, 'utf8'));
//     } catch (err) {
//         return []; // لو الملف فاضي أو مش موجود
//     }
// }

// function writeUsers(data) {
//     fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
// }

// // 1. Add User
// app.post('/user', (req, res) => {
//     let users = readUsers();
//     const { name, age, email } = req.body;
    
//     // PDF Req: Check existing email
//     if (users.find(u => u.email === email)) {
//         return res.json({ message: "Email already exists." });
//     }

//     // PDF logic: ID 1, 2, etc (or Date.now() is fine, but sequential is cleaner)
//     const id = users.length > 0 ? users[users.length - 1].id + 1 : 1; 
    
//     users.push({ id, name, age, email });
//     writeUsers(users);
    
//     // PDF Req: Exact success message
//     res.json({ message: "User added successfully." });
// });

// // 2. Update User (PATCH)
// app.patch('/user/:id', (req, res) => {
//     let users = readUsers();
//     const id = Number(req.params.id);
    
//     const userIndex = users.findIndex(u => u.id === id);

//     // PDF Req: Handle ID not found
//     if (userIndex === -1) {
//         return res.json({ message: "User ID not found." });
//     }

//     // Update logic
//     users[userIndex] = { ...users[userIndex], ...req.body };
//     writeUsers(users);

//     res.json({ message: "User age updated successfully." });
// });

// // 3. Delete User
// app.delete('/user/:id', (req, res) => {
//     let users = readUsers();
//     const id = Number(req.params.id || req.body.id); // PDF implies body or params

//     const userIndex = users.findIndex(u => u.id === id);

//     // PDF Req: Handle ID not found
//     if (userIndex === -1) {
//         return res.json({ message: "User ID not found." });
//     }

//     users.splice(userIndex, 1);
//     writeUsers(users);

//     res.json({ message: "User deleted successfully." });
// });

// // 4. Get User By Name
// app.get('/user/getByName', (req, res) => {
//     let users = readUsers();
//     const { name } = req.query;
    
//     // PDF Req: Return single object, not array
//     const user = users.find(u => u.name == name);

//     if (user) {
//         res.json(user);
//     } else {
//         res.json({ message: "User name not found." });
//     }
// });

// // 5. Get All Users
// app.get('/user', (req, res) => {
//     res.json(readUsers());
// });

// // 6. Filter by Min Age
// app.get('/user/filter', (req, res) => {
//     let users = readUsers();
//     // PDF Req: Query param is 'minAge'
//     const minAge = Number(req.query.minAge);

//     const filtered = users.filter(u => u.age >= minAge);

//     if (filtered.length > 0) {
//         res.json(filtered);
//     } else {
//         res.json({ message: "no user found" });
//     }
// });

// // 7. Get User By ID
// app.get('/user/:id', (req, res) => {
//     let users = readUsers();
//     const id = Number(req.params.id);
    
//     const user = users.find(u => u.id === id);

//     if (user) {
//         res.json(user);
//     } else {
//         res.json({ message: "User not found." });
//     }
// });

// app.listen(3000, () => console.log('Server running on port 3000'));